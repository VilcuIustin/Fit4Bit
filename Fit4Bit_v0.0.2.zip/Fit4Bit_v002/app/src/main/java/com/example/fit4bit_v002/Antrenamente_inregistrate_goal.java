package com.example.fit4bit_v002;

import android.os.Bundle;
import android.os.PersistableBundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;

public class Antrenamente_inregistrate_goal extends AppCompatActivity {

    private RecyclerView antrenamenteRecView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.antrenamente_inregistrate_goal);
            this.setTitle("Antrenamente");
            antrenamenteRecView = findViewById(R.id.antrenamenteRecView);

            ArrayList<Antrenament> listaAntrenamente = new ArrayList<>();
            ArrayList<Exercitiu> exercitii = new ArrayList<>();

            exercitii.add(new Exercitiu("cocoseala", new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5)), new ArrayList<Integer>( Arrays.asList(10, 20, 30, 40))));
            exercitii.add(new Exercitiu("cocoseala1", new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5)), new ArrayList<Integer>( Arrays.asList(10, 20, 30, 40))));


        listaAntrenamente.add(new Antrenament("Picioare", exercitii, 65));
        listaAntrenamente.add(new Antrenament("Picioare2", exercitii, 65));
        listaAntrenamente.add(new Antrenament("Picioare3", exercitii, 65));
        listaAntrenamente.add(new Antrenament("Picioare4", exercitii, 65));
        listaAntrenamente.add(new Antrenament("Picioare5", exercitii, 65));
        listaAntrenamente.add(new Antrenament("Picioare6", exercitii, 65));




        AntrenamenteRecViewAdapter adapterr = new AntrenamenteRecViewAdapter(this);
        adapterr.setListaAntrenamente(listaAntrenamente);
        antrenamenteRecView.setLayoutManager(new LinearLayoutManager(this));
        antrenamenteRecView.setAdapter(adapterr);
        }
}
