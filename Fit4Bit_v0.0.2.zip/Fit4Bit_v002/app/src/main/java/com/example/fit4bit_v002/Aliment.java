package com.example.fit4bit_v002;

public class Aliment {

    private String denumire;
    private int calorii;
    private double cantitate;
    private Macronutrient macronutrienti;

    Aliment(String denumire, int calorii, double cantitate, Macronutrient macronutrienti) {
        this.denumire = denumire;
        this.calorii = calorii;
        this.cantitate = cantitate;
        this.macronutrienti = macronutrienti;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public int getCalorii() {
        return calorii;
    }

    @Override
    public String toString() {
        return denumire + "\ncalorii: " + calorii + "\ncantitate: " + cantitate
                + "g" + "\nmacronutrienti: " + macronutrienti;
    }

    public Macronutrient getMacronutrient()
    {
        return macronutrienti;
    }

    public void setCalorii(int calorii) {
        this.calorii = calorii;
    }

    public double getCantitate() {
        return cantitate;
    }

    public void setCantitate(double cantitate) {
        this.cantitate = cantitate;
    }

}
