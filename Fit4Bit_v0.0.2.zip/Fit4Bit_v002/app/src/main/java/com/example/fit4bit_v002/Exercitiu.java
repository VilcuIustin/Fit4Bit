package com.example.fit4bit_v002;

import java.util.ArrayList;

public class Exercitiu {
    private String denumire;
    private ArrayList<Integer> serie;
    private ArrayList<Integer> repetari;

    public Exercitiu(String denumire,ArrayList<Integer> serie,ArrayList<Integer> repetari) {
        this.denumire = denumire;
        this.serie = new ArrayList<Integer>();
        this.repetari = new ArrayList<Integer>();
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public ArrayList<Integer> getSerie() {
        return serie;
    }

    public void setSerie(ArrayList<Integer> serie) {
        this.serie = serie;
    }

    public ArrayList<Integer> getRepetari() {
        return repetari;
    }

    public void setRepetari(ArrayList<Integer> repetari) {
        this.repetari = repetari;
    }

    @Override
    public String toString() {
        return "Exercitiu{" +
                "denumire='" + denumire + '\'' +
                ", serie=" + serie +
                ", repetari=" + repetari +
                '}';
    }
}


