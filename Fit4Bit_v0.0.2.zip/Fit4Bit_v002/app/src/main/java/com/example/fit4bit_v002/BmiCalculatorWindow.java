package com.example.fit4bit_v002;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BmiCalculatorWindow extends AppCompatActivity {

    private EditText txt_masa, txt_inaltime;
    private TextView rezultat_bmi_1, rezultat_bmi_2;
    private Button buton_calculeaza_bmi;

    private double masa, inaltime, bmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("Calculator BMI");
        setContentView(R.layout.bmi_calculator_free);

        txt_masa = findViewById(R.id.txt_nd_masa);
        txt_inaltime = findViewById(R.id.txt_nd_inaltime);

        rezultat_bmi_1 = findViewById(R.id.rezultat_bmi_1);
        rezultat_bmi_2 = findViewById(R.id.rezultat_bmi_2);

        buton_calculeaza_bmi = findViewById(R.id.buton_calculeaza_bmi);


        buton_calculeaza_bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BmiCalculator BMI = new BmiCalculator();
                masa = Double.parseDouble(txt_masa.getText().toString());
                inaltime = Double.parseDouble(txt_inaltime.getText().toString());
                bmi = BMI.calculeazaBMI(masa, inaltime);


                rezultat_bmi_1.setText("" + BMI.calculeazaBMI(masa, inaltime));
                rezultat_bmi_2.setText("" + BMI.rezultatBMI(BMI.calculeazaBMI(masa, inaltime)));

                AlertDialogBmiCalculator alertDialogBmiCalculator = new AlertDialogBmiCalculator(v, bmi);
            }
        });
    }
}
