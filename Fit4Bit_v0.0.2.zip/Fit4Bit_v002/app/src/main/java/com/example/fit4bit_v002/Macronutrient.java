package com.example.fit4bit_v002;

public class Macronutrient {
    private double proteine;
    private double carbohridrati;
    private double grasimi;

    Macronutrient(double proteine, double carbohidrati, double grasimi) {
        this.carbohridrati = carbohidrati;
        this.proteine = proteine;
        this.grasimi = grasimi;
    }

    double getProteine() {
        return this.proteine;
    }

    double getCarbohidrati() {
        return this.carbohridrati;
    }

    double getGrasimi() {
        return this.grasimi;
    }

    void setGrasimi(double grasimi) {
        this.grasimi = grasimi;
    }

    void setProteine(double proteine) {
        this.proteine = proteine;
    }

    void setCarbohidrati(double carbohidrati) {
        this.carbohridrati = carbohidrati;
    }

    @Override
    public String toString() {
        return "\nproteine: " + proteine + "g" + " carbohridrati: " + carbohridrati + "g" + " grasimi: " + grasimi
                + "g";
    }

}
