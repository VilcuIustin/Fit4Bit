package com.example.fit4bit_v002;

import java.util.ArrayList;

public class Antrenament {
    private String denumire;
    private ArrayList<Exercitiu> exercitii;
    private double durata;

    public Antrenament(String denumire, ArrayList<Exercitiu> exercitii, double durata) {
        this.denumire = denumire;
        this.exercitii = exercitii;
        this.durata = durata;
    }

    public Antrenament(String denumire, double durata) {
        this.denumire = denumire;
        this.exercitii = new ArrayList<Exercitiu>();
        this.durata = durata;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public ArrayList<Exercitiu> getExercitii() {
        return exercitii;
    }


    public double getDurata() {
        return durata;
    }

    public void setDurata(double durata) {
        this.durata = durata;
    }

    @Override
    public String toString() {
        return "Antrenament [denumire=" + denumire + ", exercitii=" + exercitii + ", durata=" + durata + "]";
    }

}
