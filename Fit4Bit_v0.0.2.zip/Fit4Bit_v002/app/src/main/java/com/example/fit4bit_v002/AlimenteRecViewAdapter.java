package com.example.fit4bit_v002;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AlimenteRecViewAdapter extends RecyclerView.Adapter<AlimenteRecViewAdapter.ViewHolder> {


    private ArrayList<Aliment> alimente = new ArrayList<>();
    private int id = 0;

    public AlimenteRecViewAdapter() {

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_alimente, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtNumeAliment.setText(alimente.get(position).toString());
        holder.detaliiAliment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialogAliment popup = new AlertDialogAliment(v);
            }
        });
        holder.parinte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return alimente.size();
    }

    public void setAlimente(ArrayList<Aliment> alimente) {
        this.alimente = alimente;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView txtNumeAliment;
        private RelativeLayout parinte;
        private Button detaliiAliment;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNumeAliment = itemView.findViewById(R.id.nume_aliment);
            parinte = itemView.findViewById(R.id.parinteLA);
            detaliiAliment = itemView.findViewById(R.id.detaliiAliment);
        }
    }
}
