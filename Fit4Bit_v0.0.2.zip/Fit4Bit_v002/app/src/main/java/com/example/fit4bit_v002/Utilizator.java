package com.example.fit4bit_v002;

public class Utilizator {
    private String nume;
    private int varsta;
    private char sex;
    private double inaltime, masa;

    public Utilizator(double inaltime, double masa, String nume, int varsta, char sex) {
        this.inaltime = inaltime;
        this.masa = masa;
        this.nume = nume;
        this.varsta = varsta;
        this.sex = sex;
    }

    public Utilizator() {
    }

    public double getInaltime() {
        return inaltime;
    }

    public void setInaltime(double inaltime) {
        this.inaltime = inaltime;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public String getNume() {
        return nume;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    @Override
    public String toString() {
        return "Utilizator [nume=" + nume + ", varsta=" + varsta + ", sex=" + sex + ", inaltime=" + inaltime + ", masa="
                + masa + ", activ=" + "]";
    }
}
