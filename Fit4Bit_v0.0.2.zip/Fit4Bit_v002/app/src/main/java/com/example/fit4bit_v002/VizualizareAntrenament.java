package com.example.fit4bit_v002;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VizualizareAntrenament extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vizualizare_antrenament);
        TextView t= findViewById(R.id.textView2);
        t.setText(this.getIntent().getStringExtra("NumeEx"));
        

    }
}