package com.example.fit4bit_v002;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AntrenamenteRecViewAdapter extends RecyclerView.Adapter<AntrenamenteRecViewAdapter.ViewHolder> {

    private ArrayList<Antrenament> listaAntrenamente = new ArrayList<>();
    private Antrenamente_inregistrate_goal antrenamenteGoal;
    public AntrenamenteRecViewAdapter(Antrenamente_inregistrate_goal antrenamenteGoal) {
        this.antrenamenteGoal = antrenamenteGoal;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_antrenamente, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.numeAntr.setText(listaAntrenamente.get(position).getDenumire());
        holder.durataAntr.setText(listaAntrenamente.get(position).getDurata() + "");

        holder.vizAntr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(antrenamenteGoal, VizualizareAntrenament.class);
                intent.putExtra("NumeEx",holder.numeAntr.getText());
                antrenamenteGoal.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaAntrenamente.size();
    }

    public void setListaAntrenamente(ArrayList<Antrenament> listaAntrenamente) {
        this.listaAntrenamente = listaAntrenamente;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        private TextView numeAntr, durataAntr;
        private RelativeLayout parinte;
        private Button stergeAntr, vizAntr;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            numeAntr = itemView.findViewById(R.id.nume_antrenament);
            durataAntr = itemView.findViewById(R.id.durata_antrenament);
            parinte = itemView.findViewById(R.id.parinteLA2);
            stergeAntr = itemView.findViewById(R.id.buton_sterge_antr);
            vizAntr = itemView.findViewById(R.id.buton_viz_antr);
        }
    }
}
