package com.example.fit4bit_v002;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class BmrCalculatorWindow extends AppCompatActivity {

    private EditText txt_masa, txt_inaltime, txt_varsta;
    private Button buton_calculeaza_bmr;
    private RadioButton checkM, checkF;

    private double masa, inaltime, bmr;
    private int varsta;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bmr_calculator_free);
        this.setTitle("Calculator BMR");
        txt_masa = findViewById(R.id.masa);
        txt_inaltime = findViewById(R.id.inaltime);
        txt_varsta = findViewById(R.id.txt_ns_varsta);

        checkM = findViewById(R.id.radio_m);
        checkF = findViewById(R.id.radio_f);

        buton_calculeaza_bmr = findViewById(R.id.buton_calculeaza_bmr);

        buton_calculeaza_bmr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                masa = Double.parseDouble(txt_masa.getText().toString());
                inaltime = Double.parseDouble(txt_inaltime.getText().toString());
                varsta = Integer.parseInt(txt_varsta.getText().toString());

                BmrCalculator bmrCalculator = new BmrCalculator();
                if (checkM.isChecked() == true) {
                    bmr = bmrCalculator.calculeazaBMR(masa, inaltime, varsta, "M");
                    AlertDialogBmrCalculator alertDialogBmrCalculator = new AlertDialogBmrCalculator(v, bmr);
                }
                if (checkF.isChecked() == true) {
                    bmr = bmrCalculator.calculeazaBMR(masa, inaltime, varsta, "F");
                    AlertDialogBmrCalculator alertDialogBmrCalculator = new AlertDialogBmrCalculator(v, bmr);
                }
            }
        });
    }

}
