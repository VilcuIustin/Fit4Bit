package com.example.fit4bit_v002;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class  Alimente_inregistrate_goal extends AppCompatActivity {

    private Spinner spinner_activ;
    private Utilizator utilizator;
    private double bmr;
    private RecyclerView alimenteRecView;

  //  Alimente_inregistrate_goal(){
//        spinner_activ = (Spinner) findViewById(R.id.spinner_activ);
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
//                R.array.activity_level, android.R.layout.simple_spinner_item);
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner_activ.setAdapter(adapter);
//
//        BmrCalculatorUtilizator bmrCalculatorUtilizator = new BmrCalculatorUtilizator(utilizator);
//        bmr = bmrCalculatorUtilizator.calculeazaBMR();

       // alimenteRecView
 //   }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alimente_inregistrate_goal);
//                spinner_activ = (Spinner) findViewById(R.id.spinner_activ);
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
//                R.array.activity_level, android.R.layout.simple_spinner_item);
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner_activ.setAdapter(adapter);
//
//        BmrCalculatorUtilizator bmrCalculatorUtilizator = new BmrCalculatorUtilizator(utilizator);
//        bmr = bmrCalculatorUtilizator.calculeazaBMR();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ffFEBB31"));


        alimenteRecView  =  findViewById(R.id.recycler_view_butoane_start);

        ArrayList<Aliment> listaAlimente = new ArrayList<>();
        listaAlimente.add(new Aliment("papanas",23,100,new Macronutrient(2,3,4)));
        listaAlimente.add(new Aliment("maraciuca de prune",800,100,new Macronutrient(211,13,14)));
        listaAlimente.add(new Aliment("shaorma de la Tamara",999,100,new Macronutrient(22,33,44)));
        listaAlimente.add(new Aliment("covridogamiu",200,100,new Macronutrient(22,32,24)));
        listaAlimente.add(new Aliment("carne de urs",777,100,new Macronutrient(55,77,144)));
        listaAlimente.add(new Aliment("carne de balaur",9999,100,new Macronutrient(999,999,7)));


        AlimenteRecViewAdapter adapter7 = new AlimenteRecViewAdapter();
        adapter7.setAlimente(listaAlimente);
        alimenteRecView.setLayoutManager(new LinearLayoutManager(this));
        alimenteRecView.setAdapter(adapter7);

    }

}
